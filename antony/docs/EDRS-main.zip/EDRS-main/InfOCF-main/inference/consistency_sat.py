# ---------------------------------------------------------------------------
# Standard library
# ---------------------------------------------------------------------------

import logging

# ---------------------------------------------------------------------------
# Third-party
# ---------------------------------------------------------------------------
from pysmt.shortcuts import Implies, Solver, is_sat

# ---------------------------------------------------------------------------
# Project modules
# ---------------------------------------------------------------------------
from infocf.log_setup import get_logger

logger = get_logger(__name__)


def toImplicit(conditionals):
    """
    Accepts a list of conditionals and returns a list of implications.
    """
    return [Implies(i.antecedence, i.consequence) for i in conditionals]


def checkTautologies(conditionals):
    conditionals = [i for i in conditionals.values()]
    with Solver(name="z3"):
        for c in conditionals:
            case1 = is_sat(c.make_A_then_B())
            case2 = is_sat(c.make_A_then_not_B())
            if not case1 or not case2:
                return True


def consistency(ckb, solver="z3", weakly=False):
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("solver: %s", solver)
    conditionals = [i for i in ckb.conditionals.values()]
    # partition is a list of lists
    partition = []
    ### We use the solver here, not the optimizer
    calls = 0
    levels = 0
    while True:
        with Solver(name=solver) as s:
            # if no conditionals remain, the ckb is consistent
            if len(conditionals) == 0:
                if weakly:
                    partition.append([])
                if logger.isEnabledFor(logging.DEBUG):
                    logger.debug(
                        "calls: %s, levels: %s, partition lengths: %s, status: consistent",
                        calls,
                        levels,
                        [len(i) for i in partition],
                    )
                return partition, ([len(p) for p in partition], calls, levels)
            levels += 1
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug("levels: %s", levels)
            s.push()
            knowledge = toImplicit(conditionals)
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug("knowledge: %s", knowledge)
            [s.add_assertion(k) for k in knowledge]
            R = []
            C = []
            for c in conditionals:
                calls += 1
                s.push()
                s.add_assertion(c.make_A_then_B())
                if s.solve():
                    R.append(c)
                else:
                    C.append(c)
                s.pop()
            if R == []:
                # No tolerated rules at this level.
                # Distinguish between: (a) knowledge itself inconsistent → weakly-inconsistent
                # and (b) knowledge consistent → last layer for weakly-consistency.
                if logger.isEnabledFor(logging.DEBUG):
                    logger.debug(
                        "calls: %s, levels: %s, status: no tolerated rules",
                        calls,
                        levels,
                    )
                if weakly:
                    knowledge_sat = s.solve()
                    if not knowledge_sat:
                        # Even the A→B knowledge is inconsistent → genuinely inconsistent
                        return False, ([len(C)], calls, levels)
                    # Knowledge consistent: treat remaining conditionals as last weak layer
                    partition.append(C)
                    return partition, ([len(p) for p in partition], calls, levels)
                else:
                    # Standard mode: inconsistent
                    return False, ([len(p) for p in partition], calls, levels)
            partition.append(R)
            conditionals = C
            # reset the solver sothat it wont consider the currently found partition anymore
            s.pop()


def consistency_indices(ckb, solver, weakly=False):
    conditionals = [i for i in ckb.conditionals.keys()]
    # partition is a list of lists
    partition = []
    ### We use the solver here, not the optimizer
    calls = 0
    levels = 0
    while True:
        with Solver(name=solver) as s:
            # if no conditionals remain, the ckb is consistent
            if len(conditionals) == 0:
                if weakly:
                    partition.append([])
                if logger.isEnabledFor(logging.DEBUG):
                    logger.debug(
                        "calls: %s, levels: %s, partition lengths: %s, status: consistent",
                        calls,
                        levels,
                        [len(i) for i in partition],
                    )
                return partition, ([len(p) for p in partition], calls, levels)
            levels += 1
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug("levels: %s", levels)
            s.push()
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug("conditionals: %s", [(c, type(c)) for c in conditionals])
            knowledge = toImplicit([ckb.conditionals[i] for i in conditionals])
            [s.add_assertion(k) for k in knowledge]
            R = []
            C = []
            for i in conditionals:
                calls += 1
                s.push()
                s.add_assertion(ckb.conditionals[i].make_A_then_B())
                if s.solve():
                    R.append(i)
                else:
                    C.append(i)
                s.pop()
            if R == []:
                if weakly:
                    knowledge_sat = s.solve()
                    if not knowledge_sat:
                        return False, ([len(C)], calls, levels)
                    partition.append(C)
                    return partition, ([len(p) for p in partition], calls, levels)
                else:
                    return False, ([len(p) for p in partition], calls, levels)
            partition.append(R)
            conditionals = C
            # reset the solver sothat it wont consider the currently found partition anymore
            s.pop()


def set_core_minimize(s):
    s.set("sat.core.minimize", True)  # For Bit-vector theories
    # s.set("smt.core.minimize",True)  # For general SMT

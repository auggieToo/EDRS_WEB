# a(a,b) = 1 or 0
import json, csv, re, sys, infocf
import pandas as pd

def sanitize_feature(feat_name):
    """
    Replaces parentheses and commas with underscores to prevent parsing errors.
    Example: 'a(15,9)' -> 'a_15_9'
    """
    # Replace '(', ')', and ',' with '_'
    clean_name = re.sub(r'[\(\),]', '_', feat_name)
    # Remove any trailing underscores that might result from replacing a closing parenthesis
    return clean_name.strip('_')

def convert_to_signature_format(json_input):
    # Parse the JSON string into a Python dictionary
    data = json_input
    rules = data.get("rules", [])
    
    unique_features = set()
    conditional_lines = []
    
    for rule in rules:
        label = rule.get("label", 1)
        body = rule.get("body", [])
        original_rule_str = rule.get("rule_str", "")
        
        # Consequent is 'y' if label is 1, and '!y' if label is 0
        consequent = "y" if label == 1 else "!y"
        
        antecedents = []
        for cond in body:
            raw_feat = cond["feat"]
            val = cond["val"]
            
            clean_feat = sanitize_feature(raw_feat)
            unique_features.add(clean_feat)
            
            # Apply negation ('!') if the value is 0
            if val == 1:
                antecedents.append(clean_feat)
            else:
                antecedents.append(f"!{clean_feat}")
        
        # Join antecedents with a comma
        antecedents_str = ", ".join(antecedents)
        
        # Format the conditional string for this specific rule
        cond_line = f"   ({consequent} | {antecedents_str}), "
        conditional_lines.append(cond_line)
    
    # Signature
    # We include 'y' as our target variable, followed by all unique features sorted alphabetically
    signature_vars = ["y"] + sorted(list(unique_features))
    signature_block = "signature\n   " + ", ".join(signature_vars)
    
    # Conditionals 
    # We strip the trailing comma from the very last rule to keep syntax clean
    if conditional_lines:
        conditional_lines[-1] = conditional_lines[-1].replace("), ", ") ")
        
    conditionals_block = "conditionals\nruleset {\n" + "\n".join(conditional_lines) + "\n}"

    return f"{signature_block}\n\n{conditionals_block}"

def convert_instances_to_queries(input_csv, output_file=None, target_col='y', ignore_cols=['instance_id'], num_samples=10):
    """
    Converts CSV instances into belief base query format.
    
    :param input_csv: Path to input CSV file.
    :param output_file: Optional path to save formatted queries as a text file.
    :param target_col: The target label column placed as the consequent (y or !y).
    :param ignore_cols: List of column names to exclude (e.g., primary key/ID columns).
    """
    if num_samples == 0:
        df = pd.read_csv(input_csv)
    else:
        df = pd.read_csv(input_csv).head(num_samples)

    
    # Identify feature columns (excluding target and ignored columns)
    feature_cols = [c for c in df.columns if c != target_col and c not in ignore_cols]
    
    # Pre-sanitize feature column names (e.g., 'a(15,9)' -> 'a_15_9')
    clean_cols = {col: re.sub(r'[\(\),]', '_', str(col)).strip('_') for col in feature_cols}
    
    queries = []
    for _, row in df.iterrows():
        # Get both query possibilities
        consequent = target_col
        consequent2 = f"!{target_col}"
        
        
        # Build antecedents list based on feature values
        antecedents = [
            clean_cols[col] if row[col] == 1 else f"!{clean_cols[col]}"
            for col in feature_cols
        ]
        
        # Format conditional query
        query = f"({consequent} | {', '.join(antecedents)})"
        query2 = f"({consequent2} | {', '.join(antecedents)})"
        queries.append(query)
        queries.append(query2)
    
    formatted_output = ",\n".join(queries)
    
    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(formatted_output)
        print(f"Successfully exported {len(queries)} queries to '{output_file}'.")
        
    return formatted_output

def SW_inference():

    belief_base = infocf.parse_belief_base("ruleset.cl")
    queries = infocf.parse_queries("queries.clq")

    manager = infocf.InferenceManager(belief_base, "system-w")
    results = manager.inference(queries)

    print(results)

    return results
    # manager = infocf.InferenceOperator(belief_base, "system-z")
    # results = manager.inference(queries, multi_inference=True)

    # print(results)

def main():
    with open("rules.json", "r") as f:
            data = json.load(f)
    output = convert_to_signature_format(data)
    print(output)

    # Creates a new file and writes text to it
    with open("ruleset.cl", "w") as file:
        file.write(output)

    output_queries = convert_instances_to_queries('instances.csv', output_file='queries.clq', num_samples = 0)

    sys.setrecursionlimit(100000)

    results = SW_inference()

    df = pd.read_csv('instances.csv')

    df_repeated = df.loc[df.index.repeat(2)].reset_index(drop=True)
    new_values = ['A', 'B'] * (len(df_repeated) // 2)
    df_repeated['new_column'] = new_values

    results.insert(0, 'instance_id', df_repeated['instance_id'])

    df_repeated.to_csv('output.csv', index=False)

    csvR = results.to_csv('system_W_results.csv', index=False)

if __name__ == "__main__":
    main()
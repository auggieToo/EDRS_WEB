# a(a,b) = 1 or 0
import json, csv, re, sys, infocf
import pandas as pd

class Condition:
    def __init__(self, idx, val):
        self.index = idx
        self.val  = val

class Rule:
    def __init__(self, id, cond, label):
        self.id  = id
        self.cond = cond
        self.label  = label

class Instance:
    def __init__(self, id, cond, label):
        self.id = id
        self.cond = cond
        self.label = label

def readRulesJSON(filename):
    with open(filename, "r") as f:
        data = json.load(f)

    jRules = data.get("rules")
    rules = []
    #features = jRules.get("body")
    #print(jRules[3])

    for rule in jRules:
        #print(rule.get("body"))
        body = rule.get("body")
        index = rule.get("idx")
        label = rule.get("label")
        cons = []
        for feature in body:
            #print(feature)
            #print(feature.get("val"))
            condition = Condition(feature.get("feat"), int(feature.get("val")))
            cons.append(condition)

        arule = Rule(index, cons, label)
        rules.append(arule)
        #print("\n")
    return rules
    #printRules(rules)

def readInstanceCSV(filename):
    instances = []
    with open(filename, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            lst = list(row)
            query = []
            conditions = []
            label = 0
            id = 0
            for feat in lst:
                value = row.get(feat)
                if feat == "y":
                    label = value
                elif feat == "instance_id":
                    id = value
                # feat and val are key pairs
                #print(row.get(feat))
                else:
                    conditions.append(Condition(feat, int(value)))
            instance = Instance(id, conditions, label)
            instances.append(instance)
            #print(len(conditions))
    return instances

def isSubset(conditionsA, conditionsB):
    match = 0
    for condA in conditionsA:
        for condB in conditionsB:
            if condA.index == condB.index and condA.val == condB.val:
                match += 1
    #print(match == len(conditionsB))
    return match == len(conditionsA)

def isEqual(setA, setB):
    match = 0
    for condA in setA:
            for condB in setB:
                if condA.index == condB.index and condA.val == condB.val:
                    match += 1
    return match == len(setA) and match == len(setB)

def printConditions(conditions):
    out =""
    for cond in conditions:
        out += str(cond.index) + " " + str(cond.val) + " "
    print(out)

def printInstances(instances):
    out = ""
    for instance in instances:
        out += instance.id + " "
        for conditions in instance.cond:
            out += (str(conditions.index)  ) + (" = " + str(conditions.val) + " : ")
        out += instance.label + " \n"
    print(out)

def printRules(rules):
    out = ""
    for rule in rules:
        out += "rule id = " +  str(rule.id) + " : "
        for conditions in rule.cond:
            out += (str(conditions.index)  ) + (" = " + str(conditions.val) + " , ")
        print( out + "=> " + str(rule.label) + "\n")
        out = ""

def findApplicableRules(instances, rules):
    applicable = []
    for instance in instances:
            #printConditions(instance.cond)
            flag = False
            tmpRule = []
            for rule in rules:
                if isSubset(rule.cond, instance.cond) :
                    if not flag:
                        tmpRule.append(rule.id)
                        flag = True
                    else:
                        tmpRule.append(rule.id)
            applicable.append((tmpRule, instance.id))
                

    return applicable

def validateSanityAssumption(rules):
    violations = []
    for i in range(len(rules)):
        for j in range(i, len(rules)):
            body1 = rules[i].cond
            body2 = rules[j].cond
            if isEqual(body1, body2) and i != j:
                # assumptions violated
                violations.append((i,j))
    return violations

def validateStrictGlobalClosure(rules):
    violations =[]
    for i in range(len(rules)):
        for j in range(len(rules)):
            if rules[i].label != rules[j].label and isSubset(rules[i].cond, rules[j].cond):
                violations.append((i,j))
    return violations

def validateNoTotalOverride(rules, applicable):
    violations = set()
    for i in range(len(rules)):
        flag = False
        for j in range(len(applicable)):
            if(len(applicable[j][0]) == 1 ):
                violations.add(applicable[j][0][0])
       
    return violations

def printECCRS_MSW_predictions(rules, applicable):
    out = "ECCRS_MSW PREDICTIONS\n"
    fields = ['instance_id', 'applicable_rules', 'overrides', 'incl_max', 'prediction']
    data = []
    applR= []
    for instance in applicable:
        record_index = instance[1]
        out += "record index: " + record_index + "\t : "
        
        #applR.append(int(instance[0][0]))
        overrides = ""
        if(len(instance[0]) > 1):
            # more than 1 rule applies
            j = len(instance[0]) - 1
            while(True):
                
                if j > 0:
                    out += " r" + str(instance[0][j]) + " applies overridden by"
                    overrides += " r" + str(instance[0][j]) + " applies overridden by"
                    applR.append(int(instance[0][j]))
                else:
                    break
                j -= 1
    
        
        rule = rules[instance[0][0]].id
        applR.append(rules[instance[0][0]].id)
        label = rules[instance[0][0]].label
        out += " r" + str(rule) + ": final label = " + str(label) + "\n"
        overrides += " r" + str(rule)
        data.append([record_index, applR, overrides, " r" + str(rule), "y=" + str(label)])
        applR= []
    print(out)
    with open('eccrs_pred_traces.csv', mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        
        writer.writerow(fields)  # Write the header row
        writer.writerows(data)    # Write multiple data rows


def sanitize_feature(feat_name):
    """
    Replaces parentheses and commas with underscores to prevent parsing errors.
    Example: 'a(15,9)' -> 'a_15_9'
    """
    # Replace '(', ')', and ',' with '_'
    clean_name = re.sub(r'[\(\),]', '_', feat_name)
    # Remove any trailing underscores that might result from replacing a closing parenthesis
    return clean_name.strip('_')

def convert_to_signature_format(json_input):
    # Parse the JSON string into a Python dictionary
    data = json_input
    rules = data.get("rules", [])
    
    unique_features = set()
    conditional_lines = []
    
    for rule in rules:
        label = rule.get("label", 1)
        body = rule.get("body", [])
        original_rule_str = rule.get("rule_str", "")
        
        # Consequent is 'y' if label is 1, and '!y' if label is 0
        consequent = "y" if label == 1 else "!y"
        
        antecedents = []
        for cond in body:
            raw_feat = cond["feat"]
            val = cond["val"]
            
            clean_feat = sanitize_feature(raw_feat)
            unique_features.add(clean_feat)
            
            # Apply negation ('!') if the value is 0
            if val == 1:
                antecedents.append(clean_feat)
            else:
                antecedents.append(f"!{clean_feat}")
        
        # Join antecedents with a comma
        antecedents_str = ", ".join(antecedents)
        
        # Format the conditional string for this specific rule
        cond_line = f"   ({consequent} | {antecedents_str}), "
        conditional_lines.append(cond_line)
    
    # Signature
    # We include 'y' as our target variable, followed by all unique features sorted alphabetically
    signature_vars = ["y"] + sorted(list(unique_features))
    signature_block = "signature\n   " + ", ".join(signature_vars)
    
    # Conditionals 
    # We strip the trailing comma from the very last rule to keep syntax clean
    if conditional_lines:
        conditional_lines[-1] = conditional_lines[-1].replace("), ", ") ")
        
    conditionals_block = "conditionals\nruleset {\n" + "\n".join(conditional_lines) + "\n}"

    return f"{signature_block}\n\n{conditionals_block}"

def convert_instances_to_queries(input_csv, output_file=None, target_col='y', ignore_cols=['instance_id'], num_samples=10):
    """
    Converts CSV instances into belief base query format.
    
    :param input_csv: Path to input CSV file.
    :param output_file: Optional path to save formatted queries as a text file.
    :param target_col: The target label column placed as the consequent (y or !y).
    :param ignore_cols: List of column names to exclude (e.g., primary key/ID columns).
    """
    if num_samples == 0:
        df = pd.read_csv(input_csv)
    else:
        df = pd.read_csv(input_csv).head(num_samples)

    
    # Identify feature columns (excluding target and ignored columns)
    feature_cols = [c for c in df.columns if c != target_col and c not in ignore_cols]
    
    # Pre-sanitize feature column names (e.g., 'a(15,9)' -> 'a_15_9')
    clean_cols = {col: re.sub(r'[\(\),]', '_', str(col)).strip('_') for col in feature_cols}
    
    queries = []
    for _, row in df.iterrows():
        # Determine consequent (y if 1, !y if 0)
        consequent = target_col if row[target_col] == 1 else f"!{target_col}"
        
        # Build antecedents list based on feature values
        antecedents = [
            clean_cols[col] if row[col] == 1 else f"!{clean_cols[col]}"
            for col in feature_cols
        ]
        
        # Format conditional query
        query = f"({consequent} | {', '.join(antecedents)})"
        queries.append(query)
    
    formatted_output = ",\n".join(queries)
    
    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(formatted_output)
        print(f"Successfully exported {len(queries)} queries to '{output_file}'.")
        
    return formatted_output

def SW_inference():

    belief_base = infocf.parse_belief_base("ruleset.cl")
    queries = infocf.parse_queries("queries.cl")

    manager = infocf.InferenceManager(belief_base, "system-w")
    results = manager.inference(queries)

    print(results)

    csvR = results.to_csv('system_W_results.csv', index=True)

    return results
    # manager = infocf.InferenceOperator(belief_base, "system-z")
    # results = manager.inference(queries, multi_inference=True)

    # print(results)


def main():
    #cons = [Condition(2,0), Condition(4,1), Condition(7,1), Condition(8,0)]
    #rules = [Rule(0, cons, 1), Rule(0, cons, 1)]
    #printRules(rules)

    rules = readRulesJSON("rules.json")
    #printRules(rules)

    instances = readInstanceCSV("instances.csv")
    #printInstances(instances)

    applicable = findApplicableRules(instances, rules)
    #print(applicable)
    printECCRS_MSW_predictions(rules,applicable)

    #printConditions(rules[19].cond)
    #printConditions(rules[20].cond)
    #print(isEqual(rules[4].cond, rules[5].cond))
    #print(rules[18].label)

    # print("Sanity Violations: " + str(validateSanityAssumption(rules)))
    # print("Strict Global Closure: " + str(validateStrictGlobalClosure(rules)))
    # print("No Total Overrides: " + str(validateNoTotalOverride(rules, applicable)))
     
    # with open("rules.json", "r") as f:
    #         data = json.load(f)
    # output = convert_to_signature_format(data)
    # print(output)

    # # Creates a new file and writes text to it
    # with open("ruleset.cl", "w") as file:
    #     file.write(output)

    # output_queries = convert_instances_to_queries('instances.csv', output_file='queries.cl', num_samples = 0)

    # sys.setrecursionlimit(100000)
    # SW_inference()


if __name__ == "__main__":
    main()
import pandas as pd

df = pd.read_csv('system_W_results.csv')

#df.at[row_label, col_label]
newDf = pd.DataFrame()

ent = []
ent_not = []
undecided = []
inconsistent = []

for i in range(1,len(df),2):
    #print(df.iat[i, 0])
    

    # retrieve the entailed label True and False => entails y
    ent_not_y = df.iat[i,2]

    ent_y = df.iat[i-1,2]
    #print(ent_not_y)

    ent.append(int(ent_y))
    ent_not.append(int(ent_not_y))

    undy = 0
    incon = 0

    if ent_y == True and ent_not_y == True:
        incon = 1
        undy = 0
    elif ent_y == False and ent_not_y == False:
        undy = 1 
        incon = 0
    undecided.append(undy)
    inconsistent.append(incon)
    

out = df['instance_id'].iloc[::2].tolist()
newDf['instance_id'] = out
newDf['entails_m'] = ent
newDf['not_entails_m'] = ent_not
newDf['abstain'] = undecided


print(newDf)

output = newDf.to_csv('system_W_results_Final.csv', index=False)
#newDf['entails_m'] = 
#print(out)
#print(newDf)

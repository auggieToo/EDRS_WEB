# a(a,b) = 1 or 0
import json, csv, re, sys, infocf
import pandas as pd

class Condition:
    def __init__(self, idx, val):
        self.index = idx
        self.val  = val

class Rule:
    def __init__(self, id, cond, label):
        self.id  = id
        self.cond = cond
        self.label  = label

class Instance:
    def __init__(self, id, cond, label):
        self.id = id
        self.cond = cond
        self.label = label

def readRulesJSON(filename):
    with open(filename, "r") as f:
        data = json.load(f)

    jRules = data.get("rules")
    rules = []
    #features = jRules.get("body")
    #print(jRules[3])

    for rule in jRules:
        #print(rule.get("body"))
        body = rule.get("body")
        index = rule.get("idx")
        label = rule.get("label")
        cons = []
        for feature in body:
            #print(feature)
            #print(feature.get("val"))
            condition = Condition(feature.get("feat"), int(feature.get("val")))
            cons.append(condition)

        arule = Rule(index, cons, label)
        rules.append(arule)
        #print("\n")
    return rules
    #printRules(rules)

def readInstanceCSV(filename):
    instances = []
    with open(filename, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            lst = list(row)
            query = []
            conditions = []
            label = 0
            id = 0
            for feat in lst:
                value = row.get(feat)
                if feat == "y":
                    label = value
                elif feat == "instance_id":
                    id = value
                # feat and val are key pairs
                #print(row.get(feat))
                else:
                    conditions.append(Condition(feat, int(value)))
            instance = Instance(id, conditions, label)
            instances.append(instance)
            #print(len(conditions))
    return instances

def isSubset(conditionsA, conditionsB):
    match = 0
    for condA in conditionsA:
        for condB in conditionsB:
            if condA.index == condB.index and condA.val == condB.val:
                match += 1
    #print(match == len(conditionsB))
    return match == len(conditionsA)

def isEqual(setA, setB):
    match = 0
    for condA in setA:
            for condB in setB:
                if condA.index == condB.index and condA.val == condB.val:
                    match += 1
    return match == len(setA) and match == len(setB)

def printConditions(conditions):
    out =""
    for cond in conditions:
        out += str(cond.index) + " " + str(cond.val) + " "
    print(out)

def printInstances(instances):
    out = ""
    for instance in instances:
        out += instance.id + " "
        for conditions in instance.cond:
            out += (str(conditions.index)  ) + (" = " + str(conditions.val) + " : ")
        out += instance.label + " \n"
    print(out)

def printRules(rules):
    out = ""
    for rule in rules:
        out += "rule id = " +  str(rule.id) + " : "
        for conditions in rule.cond:
            out += (str(conditions.index)  ) + (" = " + str(conditions.val) + " , ")
        print( out + "=> " + str(rule.label) + "\n")
        out = ""

def findApplicableRules(instances, rules):
    applicable = []
    for instance in instances:
            #printConditions(instance.cond)
            flag = False
            tmpRule = []
            for rule in rules:
                if isSubset(rule.cond, instance.cond) :
                    if not flag:
                        tmpRule.append(rule.id)
                        flag = True
                    else:
                        tmpRule.append(rule.id)
            applicable.append((tmpRule, instance.id))
                

    return applicable

def validateSanityAssumption(rules):
    violations = []
    for i in range(len(rules)):
        for j in range(i, len(rules)):
            body1 = rules[i].cond
            body2 = rules[j].cond
            if isEqual(body1, body2) and i != j:
                # assumptions violated
                violations.append((i,j))
    return violations

def validateStrictGlobalClosure(rules):
    violations =[]
    for i in range(len(rules)):
        for j in range(len(rules)):
            if rules[i].label != rules[j].label and isSubset(rules[i].cond, rules[j].cond):
                violations.append((i,j))
    return violations

def validateNoTotalOverride(rules, applicable):
    violations = set()
    for i in range(len(rules)):
        flag = False
        for j in range(len(applicable)):
            if(len(applicable[j][0]) == 1 ):
                violations.add(applicable[j][0][0])
       
    return violations

def printECCRS_MSW_predictions(rules, applicable):
    out = "ECCRS_MSW PREDICTIONS\n"
    fields = ['instance_id', 'applicable_rules', 'overrides', 'incl_max', 'prediction']
    data = []
    applR= []
    for instance in applicable:
        record_index = instance[1]
        out += "record index: " + record_index + "\t : "
        
        #applR.append(int(instance[0][0]))
        overrides = ""
        if(len(instance[0]) > 1):
            # more than 1 rule applies
            j = len(instance[0]) - 1
            while(True):
                
                if j > 0:
                    out += " r" + str(instance[0][j]) + " applies overridden by"
                    overrides += " r" + str(instance[0][j]) + " applies overridden by"
                    applR.append(int(instance[0][j]))
                else:
                    break
                j -= 1
    
        
        rule = rules[instance[0][0]].id
        applR.append(rules[instance[0][0]].id)
        label = rules[instance[0][0]].label
        out += " r" + str(rule) + ": final label = " + str(label) + "\n"
        overrides += " r" + str(rule)
        data.append([record_index, applR, overrides, " r" + str(rule), "y=" + str(label)])
        applR= []
    print(out)
    with open('eccrs_pred_traces.csv', mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        
        writer.writerow(fields)  # Write the header row
        writer.writerows(data)    # Write multiple data rows


def main():
    #cons = [Condition(2,0), Condition(4,1), Condition(7,1), Condition(8,0)]
    #rules = [Rule(0, cons, 1), Rule(0, cons, 1)]
    #printRules(rules)

    rules = readRulesJSON("rules.json")
    #printRules(rules)

    instances = readInstanceCSV("instances.csv")
    #printInstances(instances)

    applicable = findApplicableRules(instances, rules)
    #print(applicable)
    printECCRS_MSW_predictions(rules,applicable)

    #printConditions(rules[19].cond)
    #printConditions(rules[20].cond)
    #print(isEqual(rules[4].cond, rules[5].cond))
    #print(rules[18].label)

    # print("Sanity Violations: " + str(validateSanityAssumption(rules)))
    # print("Strict Global Closure: " + str(validateStrictGlobalClosure(rules)))
    # print("No Total Overrides: " + str(validateNoTotalOverride(rules, applicable)))

if __name__ == "__main__":
    main()
signature
   y, a_1, a_2, a_4, a_5, a_7, a_8

conditionals
ruleset {
   (y | !a_2, a_4, a_7, !a_8), 
   (y | !a_2, a_4, !a_7, !a_8), 
   (y | !a_1, a_2, !a_4, !a_5), 
   (!y | a_1, a_2, !a_5, a_7), 
   (y | !a_1, a_2, a_4, !a_5), 
   (y | a_1, a_2, !a_5, !a_7), 
   (y | !a_2, !a_4, !a_8), 
   (!y | a_1, a_2, !a_5), 
   (y | a_2, a_5, !a_7), 
   (y | a_2, !a_5), 
   (!y | !a_2, a_8), 
   (!y | a_2) 
}